package com.MentorConnect.MentorConnect.Entity;

public enum Role {
    ADMIN,
    MENTOR,
    MENTEE
}
