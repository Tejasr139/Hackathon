package com.MentorConnect.MentorConnect.Controller;

import com.MentorConnect.MentorConnect.Dto.CodeSubmissionDto;
import com.MentorConnect.MentorConnect.Entity.CodeSubmission;
import com.MentorConnect.MentorConnect.Service.CodeSubmissionService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/code")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class CodeSubmissionController {

    private final CodeSubmissionService codeSubmissionService;

     @PostMapping("/submit")
     public ResponseEntity<?> submitCode(@RequestBody CodeSubmissionDto dto) {
         System.out.println("Received code :"+dto.getCode());
         CodeSubmission saved = codeSubmissionService.saveSubmission(dto);
         return ResponseEntity.ok(saved);
     }

     @GetMapping("/submissions")
     public ResponseEntity<?> getByEmail(@RequestParam String email) {
         return ResponseEntity.ok(codeSubmissionService.getSubmissions(email));
     }
}
