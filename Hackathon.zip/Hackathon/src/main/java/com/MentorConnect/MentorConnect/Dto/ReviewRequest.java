//package com.MentorConnect.MentorConnect.Dto;
//
//public class ReviewRequest {
//    private String code;
//
//    public String getCode() { return code; }
//    public void setCode(String code) { this.code = code; }
//}
