package com.MentorConnect.MentorConnect.Dto;

import lombok.Data;

@Data
public class RequestResponseDTO {
    private Long requestId;
    private String action;
}
