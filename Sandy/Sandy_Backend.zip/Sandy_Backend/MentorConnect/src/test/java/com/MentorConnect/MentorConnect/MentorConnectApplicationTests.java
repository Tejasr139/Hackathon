package com.MentorConnect.MentorConnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MentorConnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
